import React, { useState } from 'react';
import { Download, Maximize2, RefreshCw, Share2, Eye } from 'lucide-react';

interface Story {
  id: string;
  type: 'jira' | 'manual';
  content: string;
  title: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
}

interface UMLViewerProps {
  stories: Story[];
}

export const UMLViewer: React.FC<UMLViewerProps> = ({ stories }) => {
  const [activeModel, setActiveModel] = useState<'sequence' | 'class' | 'usecase'>('sequence');
  const [isGenerating, setIsGenerating] = useState(false);

  const completedStories = stories.filter(story => story.status === 'completed');
  const hasCompletedStories = completedStories.length > 0;

  const handleRegenerate = () => {
    setIsGenerating(true);
    setTimeout(() => setIsGenerating(false), 2000);
  };

  const modelTypes = [
    { id: 'sequence', name: 'Sequence Diagram', icon: '🔄' },
    { id: 'class', name: 'Class Diagram', icon: '📦' },
    { id: 'usecase', name: 'Use Case Diagram', icon: '👤' },
  ];

  return (
    <div className="flex-1 bg-gray-800/50 backdrop-blur-sm rounded-xl border border-white/10 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Eye className="w-5 h-5 text-green-400" />
          <h3 className="text-lg font-semibold text-white">UML Models</h3>
        </div>
        
        {hasCompletedStories && (
          <div className="flex items-center space-x-2">
            <button
              onClick={handleRegenerate}
              disabled={isGenerating}
              className="px-3 py-2 bg-gray-700/50 text-gray-300 rounded-lg hover:bg-gray-600/50 transition-all flex items-center space-x-2"
            >
              <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>Regenerate</span>
            </button>
            <button className="px-3 py-2 bg-gray-700/50 text-gray-300 rounded-lg hover:bg-gray-600/50 transition-all">
              <Share2 className="w-4 h-4" />
            </button>
            <button className="px-3 py-2 bg-gray-700/50 text-gray-300 rounded-lg hover:bg-gray-600/50 transition-all">
              <Maximize2 className="w-4 h-4" />
            </button>
            <button className="px-3 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all flex items-center space-x-2">
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>
        )}
      </div>

      {hasCompletedStories ? (
        <>
          {/* Model Type Selector */}
          <div className="flex space-x-1 bg-gray-700/50 rounded-lg p-1 mb-6">
            {modelTypes.map((model) => (
              <button
                key={model.id}
                onClick={() => setActiveModel(model.id as any)}
                className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2 rounded-md transition-all ${
                  activeModel === model.id
                    ? 'bg-green-600 text-white shadow-lg'
                    : 'text-gray-400 hover:text-white hover:bg-gray-600/50'
                }`}
              >
                <span>{model.icon}</span>
                <span className="text-sm">{model.name}</span>
              </button>
            ))}
          </div>

          {/* UML Model Display */}
          <div className="bg-gray-900/50 rounded-lg border border-white/5 p-8 min-h-96 relative overflow-hidden">
            {isGenerating ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <RefreshCw className="w-8 h-8 text-blue-400 animate-spin mx-auto mb-4" />
                  <p className="text-gray-400">Regenerating model...</p>
                </div>
              </div>
            ) : (
              <div className="h-full">
                {/* Mock UML Diagram */}
                <div className="flex items-center justify-center h-full">
                  <div className="text-center space-y-4">
                    <div className="text-6xl mb-4">
                      {activeModel === 'sequence' && '🔄'}
                      {activeModel === 'class' && '📦'}
                      {activeModel === 'usecase' && '👤'}
                    </div>
                    <h4 className="text-xl font-semibold text-white">
                      {modelTypes.find(m => m.id === activeModel)?.name}
                    </h4>
                    <p className="text-gray-400 max-w-md">
                      Generated from {completedStories.length} completed {completedStories.length === 1 ? 'story' : 'stories'}
                    </p>
                    
                    {/* Mock diagram elements */}
                    <div className="mt-8 space-y-4">
                      {activeModel === 'sequence' && (
                        <div className="flex justify-center space-x-8">
                          <div className="bg-blue-600/20 border border-blue-500/30 rounded-lg p-3 text-blue-300 text-sm">
                            User
                          </div>
                          <div className="bg-purple-600/20 border border-purple-500/30 rounded-lg p-3 text-purple-300 text-sm">
                            System
                          </div>
                          <div className="bg-green-600/20 border border-green-500/30 rounded-lg p-3 text-green-300 text-sm">
                            Database
                          </div>
                        </div>
                      )}
                      
                      {activeModel === 'class' && (
                        <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
                          <div className="bg-yellow-600/20 border border-yellow-500/30 rounded-lg p-3 text-yellow-300 text-sm">
                            UserController
                          </div>
                          <div className="bg-red-600/20 border border-red-500/30 rounded-lg p-3 text-red-300 text-sm">
                            UserService
                          </div>
                          <div className="bg-indigo-600/20 border border-indigo-500/30 rounded-lg p-3 text-indigo-300 text-sm">
                            UserRepository
                          </div>
                          <div className="bg-pink-600/20 border border-pink-500/30 rounded-lg p-3 text-pink-300 text-sm">
                            User
                          </div>
                        </div>
                      )}
                      
                      {activeModel === 'usecase' && (
                        <div className="space-y-3">
                          <div className="bg-cyan-600/20 border border-cyan-500/30 rounded-full px-4 py-2 text-cyan-300 text-sm inline-block">
                            Login
                          </div>
                          <div className="bg-teal-600/20 border border-teal-500/30 rounded-full px-4 py-2 text-teal-300 text-sm inline-block ml-4">
                            Manage Profile
                          </div>
                          <div className="bg-emerald-600/20 border border-emerald-500/30 rounded-full px-4 py-2 text-emerald-300 text-sm inline-block">
                            View Dashboard
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="flex items-center justify-center h-96 border-2 border-dashed border-gray-600 rounded-lg">
          <div className="text-center">
            <Eye className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-400 text-lg mb-2">No models to display</p>
            <p className="text-gray-500 text-sm">Add and process stories to generate UML models</p>
          </div>
        </div>
      )}
    </div>
  );
};